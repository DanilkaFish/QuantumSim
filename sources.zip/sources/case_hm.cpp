//////
// Intro

// Switch on string

// (c) 2011..2020 Sigrid/Jasper Neumann
// www.sirrida.de / programming.sirrida.de
// E-Mail: info@sirrida.de

// Granted to the public domain
// First version: 2013-02-20
// Last change: 2013-04-12

// Hash via hash map (STL, STL strings).
// You need G++ >= 4.5 for C++0x.
// g++ -std=c++0x
// Not checked for dupes.

#include "case_hm.hpp"

// eof.
